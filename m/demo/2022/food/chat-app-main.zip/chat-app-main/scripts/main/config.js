// ISI DENGAN PROJECT FIREBASE MILIK TEMEN-TEMEN SENDIRI
const firebaseConfig = {
    apiKey: "PUNYA-KAMU",
    authDomain: "PUNYA-KAMU",
    databaseURL: "PUNYA-KAMU",
    projectId: "PUNYA-KAMU",
    storageBucket: "PUNYA-KAMU",
    messagingSenderId: "PUNYA-KAMU",
    appId: "PUNYA-KAMU"
};

// BIAR GA KELAMAAN PAS MAU PANGGIL NANTI
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const rdb = firebase.database();
const stg = firebase.storage();

/*
    SUBSCRIBE: DEVANKA 761 
    https://www.youtube.com/c/RG761

    IG: " @dvnkz_ "
*/